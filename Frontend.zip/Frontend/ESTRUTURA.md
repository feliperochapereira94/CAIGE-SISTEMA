# Estrutura CAIGE - Frontend

## Organizacao

O frontend esta organizado por paginas, recursos compartilhados e scripts auxiliares:

```text
Frontend/
  index.html
  assets/
    css/
      autenticacao.css
      formulario.css
      menu-usuario.css
      notificacoes.css
      pacientes.css
      painel.css
      perfil.css
      questionarios.css
    images/
    js/
      controle-acesso.js
      gerenciador-questionarios.js
      menu-usuario.js
      notificacoes.js
      paciente-form-utils.js
      sidebar-menu.js
  pages/
    administracao/
      usuarios.html
    atividades/
      atividades.html
    autenticacao/
      entrar.html
    frequencia/
      relatorio-frequencia.html
    pacientes/
      editar.html
      lista.html
      novo.html
      questionario-detalhes.html
      questionarios.html
      visualizar.html
    painel/
      painel.html
```

## Modulo de Pacientes

As paginas principais do modulo de pacientes ficam em `pages/pacientes/`:

- `lista.html`: listagem, busca e filtros
- `novo.html`: novo cadastro
- `visualizar.html`: perfil completo e fluxo de questionarios
- `editar.html`: atualizacao cadastral
- `questionario-detalhes.html`: gerenciamento de prontuarios cadastrados
- `questionarios.html`: cadastro de perguntas

## Integracao API

Base da API: `http://localhost:3000`

Arquivos auxiliares principais:

- `assets/js/menu-usuario.js`
- `assets/js/controle-acesso.js`
- `assets/js/gerenciador-questionarios.js`
- `assets/js/notificacoes.js`
- `assets/js/paciente-form-utils.js`
- `assets/js/sidebar-menu.js`

## Navegacao Principal

1. `pages/pacientes/lista.html`
2. `pages/pacientes/visualizar.html?id=<id>`
3. `pages/pacientes/editar.html?id=<id>`
